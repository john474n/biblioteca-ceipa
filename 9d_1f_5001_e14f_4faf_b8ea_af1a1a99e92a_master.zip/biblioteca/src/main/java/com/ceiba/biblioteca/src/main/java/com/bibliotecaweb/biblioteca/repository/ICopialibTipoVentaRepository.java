package com.bibliotecaweb.biblioteca.repository;

import com.bibliotecaweb.biblioteca.entity.CopialibTipoVentaEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ICopialibTipoVentaRepository extends JpaRepository <CopialibTipoVentaEntity, Integer> {
}
