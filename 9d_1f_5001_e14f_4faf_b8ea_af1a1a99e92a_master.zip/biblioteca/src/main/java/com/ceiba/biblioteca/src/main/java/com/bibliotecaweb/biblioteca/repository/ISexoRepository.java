package com.bibliotecaweb.biblioteca.repository;

import com.bibliotecaweb.biblioteca.entity.SexoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ISexoRepository extends JpaRepository <SexoEntity, Integer> {
}
